# SSU DORM 배포 안내

1. ZIP 파일을 압축 해제합니다.
2. 압축 해제한 폴더 안의 파일과 src 폴더를 GitHub 저장소 최상위에 올립니다. ZIP 파일 자체를 올리면 안 됩니다.
3. Vercel에서 Add New → Project를 선택하고 GitHub 저장소를 연결합니다.
4. Root Directory는 파일을 올린 저장소 최상위로 두고 Deploy를 누릅니다.

vercel.json에 Vite, npm ci, npm run build, dist 설정을 포함했습니다.
현재 코드에는 Gemini API 호출이 없으므로 환경 변수 설정 없이 배포할 수 있습니다.
.env.example은 예시이며 실제 API 키를 GitHub에 올리지 마세요.

로컬 실행: npm install 후 npm run dev
프로덕션 빌드: npm run build